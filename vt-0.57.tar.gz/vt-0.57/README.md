vt
==

A tool set for short variant discovery in genetic sequence data.


Visit http://genome.sph.umich.edu/wiki/vt for instructions.
